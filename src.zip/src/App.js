import './App.css';
import Tickle from './Tickle';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Tickle time={new Date()}></Tickle> 
      </header>
    </div>
  );
}

export default App;
