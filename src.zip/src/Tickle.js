import React, {useState} from 'react';

function Tickle(props){
    const [time, setTime] = useState(props.time); 
    const [data, setData] = useState(['Apple', 'Ball', 'Cat', 'Dog', 'Elephant']);
    const [showTime, setShowTime] = useState(true);
    const [loanTime, setLoanTime] = useState(0);
    const [principle, setPrinciple] = useState(0);
    const [rate, setRate] = useState(0);
    const [interest, setInterest] = useState(0);

    const updateTime = () => {
        setTime(new Date());
        setData(['One', 'Two', 'Three', 'Four', 'Five'])
    }

    const toggleTime = () => {
        setShowTime(!showTime);
    }

    const updateLoanTime = (e) => {
        setLoanTime(e.target.value);
    }

    const updatePrinciple = (e) => {
        setPrinciple(e.target.value);
    }

    const updateRate = (e) => {
        setRate(e.target.value);
    }

    const calculateInterest = () => {
        setInterest((loanTime*principle*rate)/100);
    }
    
       return(
        <div>
            {/* {data.map((element,index) => {
                return <h2 id={`element${index+1}`} key={`element${index}`} onClick={toggleTime}>{element}</h2>
            })} */}
            <h1>Hello, world!</h1>
            {showTime ? <h2>It is {time.toLocaleTimeString()}</h2> : null}
            <button onClick={updateTime} >Update Time</button>
            <input type="number" onChange={updateLoanTime} placeholder="Time"></input>
            <input type="number" onChange={updatePrinciple} placeholder="Principle"></input>
            <input type="number" onChange={updateRate} placeholder="Rate"></input>
            <button onClick={calculateInterest}>Calculate Interest</button>

            <h1>Your Interest is : {interest}</h1>
        </div>
       );
}

export default Tickle;